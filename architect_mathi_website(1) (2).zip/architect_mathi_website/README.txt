ARCHITECT MATHI — PERSONAL PORTFOLIO WEBSITE

Open index.html in Chrome/Edge to view the website.

To customize:
1. Replace the contact email/phone in index.html.
2. Replace the three portfolio cards with your real projects.
3. Add project images inside the assets folder and update the HTML.
